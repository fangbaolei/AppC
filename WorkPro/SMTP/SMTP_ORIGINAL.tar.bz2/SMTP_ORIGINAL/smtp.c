/********************************************
SMTP����˵��:
1. ������ʵ�����ʼ����͵Ļ������ܣ���SSLj���ܡ����������͡����͵ȡ�
2. ���ڱ�������ʹ����SSL���ܼ��������õ�OpenSSL��ͷ�ļ��;�̬���ļ���
   ���ԣ��ڱ���˳���ǰ��Ӧ����ȷ����OpenSSL��OpenSSL�ı�����������˵����
3. ���ж��������ʱ��ÿ��������֮�����ʹ�÷ֺ�;���,��Ȼ���޷�����
********************************************/
#include <stdlib.h>    
#include <stdio.h>    
#include <string.h>    
#include <netdb.h>    
#include <sys/types.h>    
#include <sys/stat.h>    
#include <unistd.h>     
#include <fcntl.h>    
#include <sys/ioctl.h>    
#include <netinet/in.h>    
#include <sys/socket.h>    
#include <linux/if_ether.h>    
#include <net/if.h>    
#include <errno.h>  
#include <time.h>
// SSL��ͷ�ļ�����Щͷ�ļ�������OpenSSL��Դ���С�
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/x509.h>

typedef struct Smtp_Email
{
	char *pHost;                        // ���������� 
	char *pLoginName;             // ���� �˺� 
	char *pLoginPassword;       // ��½���� 
	char *pSendFrom;               // ���� �˺� 
	char *pSendTo;                   // �����˺� 
	char *pSendCc;                    //  ����,ÿ���ʼ���ַ֮�����Ҫ�Էֺ�;�����Ҳ��Ϊ��
	char *pDate;                        //   ����ʱ�䣬ʱ��+800 ��ʾ����ʱ�� 
	char *pEmailSubject;          //  �ʼ���  
	char *pMessage;                 //  �ʼ���ʾ������ 
	char *pFileName;                // �ʼ����� ������������Ϊ NULL 
	unsigned short port;             //��SMTPʹ��SSLʱ����˿ںű���Ϊ465����ʹ��ʱ��25.������ֻʹ��SSL������˿ں���Ϊ465
}st_smtp;


char  BaseToChr( unsigned char n )   
{   
    n &= 0x3F;   
    if ( n < 26 )   
        return ( char )( n + 'A' );   
    else if ( n < 52 )   
        return ( char )( n - 26 + 'a' );   
    else if ( n < 62 )   
        return ( char )( n - 52 + '0' );   
    else if ( n == 62 )   
        return '+';   
    else   
        return '/';   
}   

/******************************
��������: Base64���ܣ����ڸ������ݵļ���


*******************************/
int Base64Encode( char * const aDest, const unsigned char * aSrc, int aLen )   
{   
    char        * p = aDest;   
    int           i;   
    unsigned char t;   
   
    for ( i = 0; i < aLen; i++ )   
    {   
        switch ( i % 3 )   
        {   
        case 0 :   
            *p++ = BaseToChr( *aSrc >> 2 );   
            t = ( *aSrc++ << 4 ) & 0x3F;   
            break;   
        case 1 :   
            *p++ = BaseToChr( t | ( *aSrc >> 4 ) );   
            t = ( *aSrc++ << 2 ) & 0x3F;   
            break;   
        case 2 :   
            *p++ = BaseToChr( t | ( *aSrc >> 6 ) );   
            *p++ = BaseToChr( *aSrc++ );   
            break;   
        }   
    }   
    if ( aLen % 3 != 0 )   
    {   
        *p++ = BaseToChr( t );   
        if ( aLen % 3 == 1 )   
            *p++ = '=';   
        *p++ = '=';   
    }   
    *p = 0;
    return ( p - aDest );
}   

/******************************
��������: Base64���ܣ���Ҫ�����û���������ļ��ܡ�


*******************************/
int Base64_Code(unsigned char *s,unsigned char *d)   
{   
        char CharSet[64]=   
        {   
                'A','B','C','D','E','F','G','H',   
                'I','J','K','L','M','N','O','P',   
                'Q','R','S','T','U','V','W','X',   
                'Y','Z','a','b','c','d','e','f',   
                'g','h','i','j','k','l','m','n',   
                'o','p','q','r','s','t','u','v',   
                'w','x','y','z','0','1','2','3',   
                '4','5','6','7','8','9','+','/'   
        };   
        unsigned char In[3];   
        unsigned char Out[4];   
        int cnt=0;   
        if(!s||!d) return 0;   
        for(;*s!=0;)   
        {   
                if(cnt+4>76)   
                {   
                        *d++='\n';   
                        cnt=0;   
                }   
                if(strlen((char*)s) >=3)   
                {   
                        In[0]=*s;   
                        In[1]=*(s+1);   
                        In[2]=*(s+2);   
                        Out[0]=In[0]>>2;   
                        Out[1]=(In[0]&0x03)<<4|(In[1]&0xf0)>>4;   
                        Out[2]=(In[1]&0x0f)<<2|(In[2]&0xc0)>>6;   
                        Out[3]=In[2]&0x3f;   
                        *d=CharSet[Out[0]];   
                        *(d+1)=CharSet[Out[1]];   
                        *(d+2)=CharSet[Out[2]];   
                        *(d+3)=CharSet[Out[3]];   
                        s+=3;   
                        d+=4;   
                }   
                else if(strlen((char*)s)==1)   
                {   
                        In[0]=*s;   
                        Out[0]=In[0]>>2;   
                        Out[1]=(In[0]&0x03)<<4|0;   
                        *d=CharSet[Out[0]];   
                        *(d+1)=CharSet[Out[1]];   
                        *(d+2)='=';   
                        *(d+3)='=';   
                        s+=1;   
                        d+=4;   
                }   
                else if(strlen((char*)s)==2)   
                {   
                        In[0]=*s;   
                        In[1]=*(s+1);   
                        Out[0]=In[0]>>2;   
                        Out[1]=(In[0]&0x03)<<4|(In[1]&0xf0)>>4;   
                        Out[2]=(In[1]&0x0f)<<2|0;   
                        *d=CharSet[Out[0]];   
                        *(d+1)=CharSet[Out[1]];   
                        *(d+2)=CharSet[Out[2]];   
                        *(d+3)='=';   
                        s+=2;   
                        d+=4;   
                }   
                cnt+=4;   
        }   
        *d='\0';   
        return 1;   
}  

/******************************
��������: ��ȡSSL֤��



*******************************/
void ShowCerts(SSL *ssl)
 {
 	X509 *cert;
 	char *line = (char *)malloc(1024);
	cert = SSL_get_peer_certificate(ssl);
 	if (cert != NULL) 
	{
 	 	printf("Get certification OK!\n");
		line = X509_NAME_oneline(X509_get_subject_name(cert), 0, 0);
		//printf("certification:%s\n", line);
 		free(line);
 		line = X509_NAME_oneline(X509_get_issuer_name(cert), 0, 0);
 		//printf("Issuer:%s\n", line);
 		free(line);
 		X509_free(cert);
 	} 
	else
	{
	       free(line);
 		X509_free(cert);
		printf("No certification!\n");
	}
 }

/******************************
��������: ��ʼ��SSL��



*******************************/
SSL_CTX *SslInit()
{
       SSL_CTX *ctx;
 	SSL_library_init();
 	OpenSSL_add_all_algorithms();
 	SSL_load_error_strings();
 	ctx = SSL_CTX_new(SSLv23_client_method());
 	if (ctx == NULL) 
	{
 		ERR_print_errors_fp(stdout);
 		return NULL;
 	}
	return ctx;
}

/******************************
��������:SSL����


*******************************/
SSL * SslConnect(int sockfd,SSL_CTX *ctx)
{
	 SSL * ssl;
	 ctx = SslInit();
        ssl = SSL_new(ctx);
        SSL_set_fd(ssl, sockfd);
	 if (SSL_connect(ssl) == -1)
	 {
              ERR_print_errors_fp(stderr);
	       return NULL;
	 }
	 else 
	 {
 		 printf("Connected with %s encryption\n", SSL_get_cipher(ssl));
		 ShowCerts(ssl);
 	 }
	 return ssl;
}

/******************************
��������:SSL���ݷ���


*******************************/
int SslSend(const char* cmd, SSL * ssl)
{
    int err;
    //printf("Cmd: %s",cmd);
	if(SSL_write (ssl, cmd, strlen(cmd)) == -1)
	{
		printf("SSL send data error!!\n");
		return -1;
	}
    return 0;
}

/******************************
��������:SSL���ݽ���



*******************************/
int SslRecv(SSL * ssl)
{
     int ret;
     char recv_data[512];
     memset(recv_data,0,sizeof(recv_data));
     ret = SSL_read(ssl, recv_data, sizeof(recv_data));
     if (ret > 0)
     {
          printf("SSL get data OK:'%s', recieve number is:%d\n", recv_data, ret);
          return 0;    
     }
     else 
     {
          printf("SSL get data error!!\n");
	   return -1;   
     }
}

/******************************
��������:Socketʵ��SMTP�ͻ��˺�SMTP������������



*******************************/
int  Smtp_ConnectHost(const char *hostname,unsigned short port)   
{   
	struct sockaddr_in sockaddr;
	struct hostent *host;
	int sockfd;

	if((sockfd = socket(AF_INET,SOCK_STREAM,0) )== -1)   
	{	
		printf("CreateSocket error\n");   
		close(sockfd);	 
		return -1;	 
	}	

	if(hostname == NULL)   
	{
		return -1;  
	}
	
	if((host = gethostbyname(hostname)) == NULL)
	{
		printf("gethostbyname error !\n");   
		return -1;
	}
	
	memset(&sockaddr,0,sizeof(struct sockaddr));   
	sockaddr.sin_family = AF_INET;   
	sockaddr.sin_port   = htons(port);   
	memcpy(&sockaddr.sin_addr,host->h_addr,sizeof(struct in_addr));

	if((connect(sockfd,(struct sockaddr *)&sockaddr,sizeof(struct sockaddr))) == -1)   
	{ 
		printf("connect error\n");   
		close(sockfd);   
		return -1;   
	}
	return sockfd;   
} 

/******************************
��������: ��SSL���ܵķ�ʽ��SMTP����������



*******************************/
SSL *  Ssl_ConnetHost(int sockfd, SSL_CTX *ctx)
{
	SSL * ssl;
       if((ssl = SslConnect(sockfd,ctx)) == NULL)
	{
	       printf("SSL connect error\n");
		return NULL;  
	}
	if(SslRecv(ssl) == -1)
	{
		return NULL;   
	}
	return ssl;
}

/******************************
��������: ��¼�����ʼ������������



*******************************/
int Smtp_Login(char *username, char *password, SSL * ssl)   
{   
	char *pSendCmd = NULL;
	char tmpbuf[100] = {0};
	char UserDst[40] = {0}, PassDst[40] = {0};	
	char i;
	char *CmdStr[2] = {
       "HELO Localhost\r\n",
	"AUTH LOGIN\r\n"
	};
	char *pUser = NULL,*pPass = NULL;   
	
	if(username == NULL || password == NULL)   
	{
		return -1;
	}
	// ���Ͳ�ѯ����
	for(i = 0;i < 2; i++)
	{
		SslSend(CmdStr[i],ssl);
		if(SslRecv(ssl) == -1) 
		{
			return -1;
		}
	}
	// ���͵�¼��Ϣ
	pUser = username;   
	pPass = password;   
	Base64_Code((unsigned char *)pUser,(unsigned char *)UserDst);   
	Base64_Code((unsigned char *)pPass,(unsigned char *)PassDst);   
	sprintf(tmpbuf,"%s\r\n",UserDst);
	SslSend(tmpbuf,ssl);
	if(SslRecv(ssl) == -1)  
	{
		return -1;
	}
	sprintf(tmpbuf,"%s\r\n",PassDst);
	SslSend(tmpbuf,ssl);
	if(SslRecv(ssl) == -1)  
	{		
		return -1;
	}
	return 0;   
}   

/******************************
��������:���͸���



*******************************/
int Smtp_SendFile(const char *filename, SSL * ssl )   
{   
	int  len;   
	char *pSendCmd = NULL;
	int stringlen = 0;   
	int timedelay,timedelay1;	
	char attachname[1000],Filename[100],tmpbuf[100];
	unsigned char datasrc[58],datades[100];
	memset(attachname,0,sizeof(attachname));
	memset(Filename,0,sizeof(Filename));
	memset(tmpbuf,0,sizeof(tmpbuf));
	memset(datasrc,0,sizeof(datasrc));
	memset(datades,0,sizeof(datades));
	
	FILE *fp=NULL;           
	fp = fopen(filename,"rb");   
	if(fp==NULL)   
	{   
		printf("can not open file");   
		return -1;   
	}   

	fseek(fp,0,SEEK_END);   
	len = ftell(fp);   
	fseek(fp,0,SEEK_SET);   

	pSendCmd = "\r\n";
	SslSend(pSendCmd,ssl);
	pSendCmd = "--boundary=_LINE\r\n";
	SslSend(pSendCmd,ssl);
	sprintf(Filename,"Content-Type: text/plain;name=\"%s\"\r\n",filename);
	SslSend(Filename,ssl);
	pSendCmd = "Content-Transfer-Encoding: base64\r\n";
	SslSend(pSendCmd,ssl);
	sprintf(attachname,"Content-Disposition: attachment;filename=\"%s\"\r\n",filename);
	SslSend(attachname,ssl);
	pSendCmd = "\r\n";
	printf("Sending file,please wait ...\n");   
       SslSend(pSendCmd,ssl);
	while(!feof(fp))   
	{                   
		if(len>=57)   
		{   
			fread(datasrc,57,1,fp);   
			datasrc[57]='\0';   
			stringlen = 57;   
			len -= 57;   
		}   
		else if(len>0)   
		{   
			fread(datasrc,len,1,fp);   
			datasrc[len]='\0';   
			stringlen = len;   
			len = 0;   
		}   
		else 
		{
			break;
		}		
		Base64Encode((unsigned char *)datades,(unsigned char *)datasrc,stringlen);   
		for( timedelay=0;timedelay<1000;timedelay++)   
			for( timedelay1=0;timedelay1<1000;timedelay1++);
			{
				SslSend(datades,ssl);
			}
	}   
	fclose(fp);   	
	pSendCmd = "\r\n";
	SslSend(pSendCmd,ssl);
	sprintf(tmpbuf,"--boundary=_LINE--");
	SslSend(tmpbuf,ssl);
	printf("Send file ok\n");   
	return 0;   
}   

/******************************
��������: ��Ccͨ��RCPT TO�ĸ�ʽ����



*******************************/
int CarbonCopyRCPT(char *SendCc,SSL * ssl)
{
       char  CcTemp[80] = {0}, Cc[40] = {0};
	char *p;
	sprintf(CcTemp, "%s", SendCc);
	p = strtok(CcTemp, ";");
	while(p !=NULL)
	{
            sprintf(Cc,"RCPT TO: <%s>\r\n", p);
	     printf("Cc:%s\n", Cc);
	     SslSend(Cc,ssl);
	     if(SslRecv(ssl) == -1)   
	     {			 
		  return -1;
	     }
	     p = strtok(NULL, ";");
	}

}

/******************************
��������: ��Ccͨ��Cc�ĸ�ʽ����



*******************************/
int CarbonCopyCc(char *SendCc,SSL * ssl)
{
       char  CcTemp[80] = {0}, Cc[40] = {0};
	char *p;
	sprintf(CcTemp, "%s", SendCc);
	p = strtok(CcTemp, ";");
	while(p !=NULL)
	{
            sprintf(Cc,"Cc: <%s>\r\n", p); 
	     SslSend(Cc,ssl);
	     p = strtok(NULL, ";");
	}

}

/******************************
��������: �ʼ����͡��������͹��ܵ�ʵ�֣��Ѿ��ʼ����͵�ʵ�֡�


*******************************/
int Smtp_SendMessage(st_smtp *s,SSL * ssl)   
{   
	char *pSendCmd = NULL;
	char Date[40] = {0},Subject[40] = {0},tmpbuf[100] = {0},From[40] = {0},To[40] = {0};
	if(s->pSendFrom == NULL || s->pSendTo == NULL || s->pDate == NULL || s->pEmailSubject == NULL)   
	{   
		return -1;   
	} 
	sprintf(From,"MAIL FROM: <%s>\r\n",s->pSendFrom);
	SslSend(From,ssl);
	if(SslRecv(ssl) == -1)   
	{		 
		return -1;
	}
	sprintf(To,"RCPT TO: <%s>\r\n",s->pSendTo);   
	SslSend(To,ssl);
	if(SslRecv(ssl) == -1)   
	{			 
		return -1;
	}
	// ����
	if(s->pSendCc != NULL)
	{
             CarbonCopyRCPT(s->pSendCc,ssl);
	}
	pSendCmd = "DATA \r\n"; 
	SslSend(pSendCmd,ssl);
	if(SslRecv(ssl) == -1)   
	{			 
		return -1;
	}
	sprintf(From,"From: %s\r\n",s->pSendFrom); 
	SslSend(From,ssl);
	sprintf(To,"To: %s\r\n",s->pSendTo);
	SslSend(To,ssl);
	if(s->pSendCc != NULL)
	{
            CarbonCopyCc(s->pSendCc,ssl);
	}
	sprintf(Date,"Date: %s\r\n",s->pDate);
	SslSend(Date,ssl);
	sprintf(Subject,"Subject: %s\r\n",s->pEmailSubject);
	SslSend(Subject,ssl);
	sprintf(tmpbuf,"MIME-Version: 1.0\r\n");
	SslSend(tmpbuf,ssl);
	sprintf(tmpbuf,"Content-Type: multipart/mixed;boundary=\"boundary=_LINE\"\r\n"); 
	SslSend(tmpbuf,ssl);
	sprintf(tmpbuf,"Content-Transfer-Encoding: 7bit\r\n");
	SslSend(tmpbuf,ssl);
	pSendCmd = "This is a MIME Encoded Message\r\n";
	SslSend(pSendCmd,ssl);
	pSendCmd = "\r\n";
       SslSend(pSendCmd,ssl);	
	sprintf(tmpbuf,"--boundary=_LINE\r\n");
	SslSend(tmpbuf,ssl);
	sprintf(tmpbuf,"Content-Type: text/plain; charset=us-ascii\r\n");
	SslSend(tmpbuf,ssl);
	sprintf(tmpbuf,"Content-Transfer-Encoding: 7bit\r\n");
	SslSend(tmpbuf,ssl);
	pSendCmd = "\r\n";
	SslSend(pSendCmd,ssl);
	SslSend(s->pMessage,ssl);
	if(NULL != s->pFileName)// ���͸���
	{
		if(Smtp_SendFile(s->pFileName,ssl) == -1)	
		{	
			printf("send file error\n");
			return -1;
		}	
		printf("send file succ! \n");
	}

	return 0;   
}   
   
/******************************
��������: �˳����������


*******************************/ 
int Smtp_Quit(SSL * ssl)   
{   
	char *pSendCmd = NULL;
	pSendCmd = "\r\n";
	SslSend(pSendCmd,ssl);
	pSendCmd = "\r\n.\r\n";
	SslSend(pSendCmd,ssl);
	if(SslRecv(ssl) == -1)   
	{		
		return -1;
	}

	pSendCmd = "QUIT\r\n";
	SslSend(pSendCmd,ssl);
	if(SslRecv(ssl) == -1)   
	{		 
		return -1;
	}
	return 0;   
}  

/********************************
��������:�����ʼ�������SSL���ܡ����͡������ȹ��ܡ�



*********************************/
int Smtp_SendEmail(st_smtp *s)
{
	int sockfd;
	SSL * ssl;
	SSL_CTX *ctx;
	
	ctx = SslInit(); // ��ʼ��SSL��
	if((sockfd = Smtp_ConnectHost(s->pHost,s->port))== -1)   // SMTP����
	{   
		printf("can not connect the host\n");
		close(sockfd);
		return -1;   
	}   
	printf("Connect the smtp host\n");  
	
	if((ssl = Ssl_ConnetHost(sockfd,ctx)) == NULL)   // SSL����
	{
		printf("SSL connet  error\n");
		SSL_free(ssl);
	       SSL_CTX_free(ctx);
	       close(sockfd);
		return -1;   
	}
	printf("SSL connect Ok!\n");  
	
       if(Smtp_Login(s->pLoginName,s->pLoginPassword,ssl) == -1)   // �����¼
	{   
		printf("login error\n"); 
		SSL_free(ssl);
	       SSL_CTX_free(ctx);
	       close(sockfd);
		return -1;   
	}   
	printf("login\n"); 

	if(Smtp_SendMessage(s,ssl) == -1)   // �����ʼ�
	{   
		printf("send mail error\n");   
		SSL_free(ssl);
	       SSL_CTX_free(ctx);
	       close(sockfd);
		return -1;   
	}   
	printf("send message success! \n");
	if(Smtp_Quit(ssl) == -1)   // �˳�
	{   
		printf("Quit error\n");
		SSL_free(ssl);
	       SSL_CTX_free(ctx);
	       close(sockfd);
		return -1;   
	}   
	printf("send over\n");  
	
	// SMTP��SSL�Ľ�������
	SSL_free(ssl);
	SSL_CTX_free(ctx);
	close(sockfd);
	return 0;
}

void GetStr(char *Pswd)
{
    char GetStrBuf[40] = {0};
    printf("Please enter Email password:");
    gets(GetStrBuf);
    sprintf(Pswd, "%s", GetStrBuf);
}

int main(int argc,char *argv[])   
{   
	st_smtp s;
	char *HostName = "smtp.exmail.qq.com";
    char *UserName = "hjying15@163.com";
	char Password[40]= {0};
	char *SendTo = "hjying15@163.com";
	char *SendCc = "hjying15@163.com;a1284923996@gmail.com";
	char *Date = "2014-04-03 12:00:00 +800";
	char *EmailSub = "NVR test";
	char *Message = "Fucking Shit!!!!!";
	char *FileName = "test.txt";
	memset(&s,0,sizeof(s));
	GetStr(Password);
	s.pHost = HostName;
       s.pLoginName = UserName;
	s.pLoginPassword = Password;
	s.pSendFrom = UserName;
	s.pSendTo = SendTo;
	s.pSendCc = SendCc;
	s.pDate = Date;
	s.pEmailSubject = EmailSub;
	s.pMessage = Message;
	s.pFileName = FileName;
	s.port = 465; 
	if(Smtp_SendEmail(&s) == -1)
	{
		printf("Smtp_SendEmail error!\n");
		return -1;
	}
	
	return 0;   
}   
